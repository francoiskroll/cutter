#####################################################
# ~ cutter: minimal example using ctnnb1 data ~
#
# ... ... ...
# Francois Kroll 2026
# francois@kroll.be
#####################################################


# installation ------------------------------------------------------------

install.packages('remotes')
remotes::install_github("francoiskroll/cutter")
library(cutter)

library(here) # optional


# callMutations -----------------------------------------------------------

mut <- callMutations(copath=here('exampleDataset/crispresso/'),
                     metapath=here('exampleDataset/meta.xlsx'),
                     minnreads=3,
                     controltb=NA,
                     callSubs=TRUE,
                     exportpath=here('exampleDataset/mutcalls.csv'))

### CHECKPOINT ###
# (if come back to this analysis later, avoids to re-run above)
mut <- read.csv(here('exampleDataset/mutcalls.csv'))


# classifyReads -----------------------------------------------------------

rlab <- classifyReads(mut=mut,
                      mode='precise',
                      scaffDetect=TRUE,
                      whichScaff='std2',
                      scaffWin=NA,
                      unwantedSubs=FALSE, # we do not call substitutions as unwanted mutations, unless they are scaffold incorporation
                      exportpath=here('exampleDataset/readcalls.csv'))

### CHECKPOINT ###
# (if come back to this analysis later, avoids to re-run above)
rlab <- read.csv(here('exampleDataset/readcalls.csv'))


# ggStack plot ------------------------------------------------------------

rtal <- ggStack(rlab=rlab,
                splitby='grp',
                grporder=c('ni', 'inj'),
                locusorder=NA,
                mincov=100,
                xtextOrNo=FALSE,
                ytextOrNo=TRUE,
                panelSpacing=2,
                ynameOrNo=TRUE,
                legendOrNo=FALSE,
                titleOrNo=FALSE,
                titleSize=5,
                exportOrNo=TRUE,
                width=65,
                height=55,
                exportpath=here('exampleDataset/stack.pdf'))


# detect deletions flanked by microhomologies -----------------------------

# add simulated sample to mut
mut <- simulateDel(mut=mut,
                   nreads=1000,
                   cutDelbp=3,
                   awayfromCut=4)

# detect deletions flanked by microhomologies
mutmh <- detectMHdel(mut=mut,
                     minMHlen=1)

# export analysis to keep
write.csv(mutmh, here('exampleDataset/mutcalls_mh.csv'), row.names=FALSE)

### CHECKPOINT ###
# (if come back to this analysis later, avoids to re-run above)
mutmh <- read.csv(here('exampleDataset/mutcalls_mh.csv'))


# plot frequencies of deletions flanked by microhomologies ----------------

mhtal <- ggMHdel(mut=mutmh,
                 min_del_nreads=50,
                 #colourLight='#f1b9c7',
                 grporder=c('inj', 'sim'),
                 colourLight=NA,
                 colourManual=c('#E9EBEC', '#C26682', '#C77F93', '#CD96A4', '#FFE4EA'),
                 legendOrNo=FALSE,
                 titleOrNo=FALSE,
                 xtextOrNo=FALSE,
                 ytextOrNo=TRUE,
                 ynameOrNo=TRUE,
                 exportpath=here('exampleDataset/stackMHdel.pdf'),
                 width=70,
                 height=55)


# detect templated insertions ---------------------------------------------

mutins <- detectTemplatedIns(mut=mut,
                             allowStretchMatches=5,
                             extendNewlySeq=0,
                             searchWindowStarts=20,
                             minLCSbp=6)

# add simulated sample
mutins <- simulateIns(mutdti=mutins,
                      nreads=1000,
                      extendNewlySeq=0,
                      searchWindowStarts=20,
                      minLCSbp=6)

# above takes some time so it is a good idea to save the result
write.csv(mutins, here('exampleDataset/mutcall_templins.csv'), row.names=FALSE)

### CHECKPOINT ###
# (if come back to this analysis later, avoids to re-run above)
mutins <- read.csv(here('exampleDataset/mutcall_templins.csv'))


# plot frequencies of templated insertions --------------------------------

lctal <- ggTemplIns(mut=mutins,
                    min_ins_nreads=50,
                    grporder=c('inj', 'sim'),
                    colourLow='#e4eee0',
                    colourHigh='#304528',
                    legendOrNo=FALSE,
                    titleOrNo=FALSE,
                    xtextOrNo=FALSE,
                    ytextOrNo=TRUE,
                    ynameOrNo=TRUE,
                    exportpath=here('exampleDataset/stackTemplIns.pdf'),
                    width=70,
                    height=55)
